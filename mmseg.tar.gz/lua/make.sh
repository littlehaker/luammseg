g++ mmseg.cpp *.o -o mmseg.so -llua5.1 -shared
